#Requires -Version 5.1
# Run with Pester 5, Windows PowerShell 5.1 (64-bit), and PSSQLite installed.
BeforeAll {
    $root=Split-Path -Parent $PSScriptRoot
    Import-Module (Join-Path $root 'src/CLM.psm1') -Force
    Import-Module PSSQLite -ErrorAction Stop
    $example=Join-Path $root 'config/settings.example.json'
    $fixture=Join-Path $root 'fixtures/sample-certificates.csv'

    function New-TestEnvironment {
        $folder=Join-Path ([IO.Path]::GetTempPath()) ("CLM-Test-"+[guid]::NewGuid().ToString('N'))
        [void](New-Item -ItemType Directory -Path $folder -Force)
        $cfg=Get-Content -LiteralPath $example -Raw | ConvertFrom-Json
        $cfg.DatabasePath=Join-Path $folder 'db.sqlite'
        $cfg.MockMode=$true
        $cfg.MockCsvPath=Join-Path $folder 'mock.csv'
        $cfg.Templates.Include=@('WebServer')
        $cfg.Templates.Exclude=@('WorkstationAuthentication')
        $cfg.Collection.PageSize=2
        $cfg.Collection.FullReconcileIntervalDays=7
        $cfg.Collection.MaxRecordsPerScope=1000
        $cfg.Reporting.OutputDirectory=Join-Path $folder 'reports'
        $config=Join-Path $folder 'settings.json'
        $cfg | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $config -Encoding UTF8
        $all=@(Import-Csv -LiteralPath $fixture)
        $all | Export-Csv -LiteralPath $cfg.MockCsvPath -NoTypeInformation -Encoding UTF8
        return [pscustomobject]@{Folder=$folder;Config=$config;Csv=$cfg.MockCsvPath;Db=$cfg.DatabasePath}
    }
    function Add-MockRow {
        param([string]$Csv,[int]$Id,[string]$Template='WebServer',[string]$Expiry='2027-03-10')
        $rows=@(Import-Csv -LiteralPath $Csv)
        $rows+= [pscustomobject]@{
            CAName='LAB-ISSUING-CA01';RequestID=[string]$Id;CertificateTemplate=$Template;
            Subject="CN=web$Id.example.test";Issuer='CN=LAB-ISSUING-CA01';SerialNumber="$Id";
            CertificateHash="HASH$Id";NotBefore='2026-01-01';NotAfter=$Expiry;Requester='EXAMPLE\\svc-web'
        }
        $rows | Export-Csv -LiteralPath $Csv -NoTypeInformation -Encoding UTF8
    }
}

Describe 'CLM v0.2 collector and SQLite reconciliation' {
    BeforeEach { $env=New-TestEnvironment }
    AfterEach {
        if ($null -ne $env -and (Test-Path $env.Folder)) {
            Remove-Item -LiteralPath $env.Folder -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    It 'dry-runs mock discovery without creating a database' {
        $runs=@(Sync-CLMCertificates -ConfigPath $env.Config -DryRun)
        $runs.Count | Should -Be 1
        $runs[0].New | Should -Be 1
        $runs[0].DryRun | Should -BeTrue
        (Test-Path -LiteralPath $env.Db) | Should -BeFalse
    }

    It 'filters template and persists one certificate with a scope cursor' {
        $result=@(Sync-CLMCertificates -ConfigPath $env.Config)
        $result[0].Read | Should -Be 1
        $result[0].New | Should -Be 1
        $cert=@(Get-CLMCertificate -ConfigPath $env.Config)
        $cert.Count | Should -Be 1
        $cert[0].template | Should -Be 'WebServer'
        $state=@(Get-CLMCollectionState -ConfigPath $env.Config)
        $state.Count | Should -Be 1
        [int]$state[0].last_request_id | Should -Be 101
    }

    It 'uses incremental cursor then full reconciliation without duplicate or owner loss' {
        Sync-CLMCertificates -ConfigPath $env.Config | Out-Null
        $cert=@(Get-CLMCertificate -ConfigPath $env.Config)[0]
        Set-CLMCertificateOwner -ConfigPath $env.Config -CertificateId $cert.id `
            -OwnerName 'PKI Team' -Email 'pki@example.test' -Team 'Infrastructure' | Out-Null
        Set-CLMRenewalStatus -ConfigPath $env.Config -CertificateId $cert.id -Status in_progress -Notes 'CHG-123'
        Add-MockRow -Csv $env.Csv -Id 202
        $next=@(Sync-CLMCertificates -ConfigPath $env.Config)
        $next[0].Mode | Should -Be 'incremental'
        $next[0].Read | Should -Be 1
        $next[0].New | Should -Be 1
        $full=@(Sync-CLMCertificates -ConfigPath $env.Config -Full)
        $full[0].Read | Should -Be 2
        $full[0].Unchanged | Should -Be 2
        $all=@(Get-CLMCertificate -ConfigPath $env.Config)
        $all.Count | Should -Be 2
        (@($all | Where-Object id -eq $cert.id)[0]).owner_name | Should -Be 'PKI Team'
        (@($all | Where-Object id -eq $cert.id)[0]).renewal_status | Should -Be 'in_progress'
    }

    It 'updates CA metadata without changing certificate identity, owner, or renewal details' {
        Sync-CLMCertificates -ConfigPath $env.Config | Out-Null
        $before=@(Get-CLMCertificate -ConfigPath $env.Config)[0]
        $firstSeen=@(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT first_seen FROM certificates WHERE id=@id' -SqlParameters @{id=$before.id})[0].first_seen
        Set-CLMCertificateOwner -ConfigPath $env.Config -CertificateId $before.id `
            -OwnerName 'PKI Team' -Email 'pki@example.test' -Team 'Infrastructure' | Out-Null
        Set-CLMRenewalStatus -ConfigPath $env.Config -CertificateId $before.id -Status in_progress -Notes 'CHG-123'
        $rows=@(Import-Csv -LiteralPath $env.Csv)
        ($rows | Where-Object { $_.RequestID -eq '101' })[0].Subject='CN=updated.example.test'
        $rows | Export-Csv -LiteralPath $env.Csv -NoTypeInformation -Encoding UTF8
        $result=@(Sync-CLMCertificates -ConfigPath $env.Config -Full)
        $result[0].Updated | Should -Be 1
        $after=@(Get-CLMCertificate -ConfigPath $env.Config)[0]
        $after.id | Should -Be $before.id
        $after.subject | Should -Be 'CN=updated.example.test'
        $after.owner_name | Should -Be 'PKI Team'
        $after.renewal_status | Should -Be 'in_progress'
        @(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT first_seen FROM certificates WHERE id=@id' -SqlParameters @{id=$before.id})[0].first_seen | Should -Be $firstSeen
        @(Invoke-SqliteQuery -DataSource $env.Db -Query "SELECT id FROM events WHERE event_type='source_changed'").Count | Should -Be 1
    }

    It 'can update owner and renewal status twice without using modern SQLite UPSERT syntax' {
        Sync-CLMCertificates -ConfigPath $env.Config | Out-Null
        $cert=@(Get-CLMCertificate -ConfigPath $env.Config)[0]
        Set-CLMCertificateOwner -ConfigPath $env.Config -CertificateId $cert.id `
            -OwnerName 'PKI Team' -Email 'old@example.test' | Out-Null
        Set-CLMCertificateOwner -ConfigPath $env.Config -CertificateId $cert.id `
            -OwnerName 'PKI Team' -Email 'new@example.test' | Out-Null
        Set-CLMRenewalStatus -ConfigPath $env.Config -CertificateId $cert.id -Status assigned
        Set-CLMRenewalStatus -ConfigPath $env.Config -CertificateId $cert.id -Status in_progress -Notes 'CHG-234'
        $after=@(Get-CLMCertificate -ConfigPath $env.Config)[0]
        $after.email | Should -Be 'new@example.test'
        $after.renewal_status | Should -Be 'in_progress'
        @(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT id FROM owners').Count | Should -Be 1
        @(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT certificate_id FROM assignments').Count | Should -Be 1
        @(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT certificate_id FROM renewal_workflows').Count | Should -Be 1
    }

    It 'rejects empty scope before any database writes' {
        $cfg=Get-Content $env.Config -Raw | ConvertFrom-Json
        $cfg.Templates.Include=@()
        $cfg | ConvertTo-Json -Depth 12 | Set-Content $env.Config
        { Sync-CLMCertificates -ConfigPath $env.Config } | Should -Throw
        (Test-Path $env.Db) | Should -BeFalse
    }

    It 'fails on malformed records without changing inventory or cursor' {
        Add-MockRow -Csv $env.Csv -Id 105 -Expiry 'not-a-date'
        { Sync-CLMCertificates -ConfigPath $env.Config } | Should -Throw
        @(Get-CLMCertificate -ConfigPath $env.Config).Count | Should -Be 0
        @(Get-CLMCollectionState -ConfigPath $env.Config).Count | Should -Be 0
        $runs=@(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT * FROM collection_runs')
        $runs[0].status | Should -Be 'failed'
    }

    It 'rolls back a failed transaction including events and watermark' {
        Add-MockRow -Csv $env.Csv -Id 202
        Initialize-CLMDatabase -ConfigPath $env.Config | Out-Null
        $triggerSql=@'
CREATE TRIGGER reject_202 BEFORE INSERT ON certificates
WHEN NEW.request_id='202' BEGIN SELECT RAISE(FAIL,'Injected failure'); END;
'@
        Invoke-SqliteQuery -DataSource $env.Db -Query $triggerSql | Out-Null
        $failureMessage=''
        try { Sync-CLMCertificates -ConfigPath $env.Config | Out-Null }
        catch { $failureMessage=$_.Exception.Message }
        $failureMessage | Should -Match 'Injected failure'
        @(Get-CLMCertificate -ConfigPath $env.Config).Count | Should -Be 0
        @(Get-CLMCollectionState -ConfigPath $env.Config).Count | Should -Be 0
        $events=@(Invoke-SqliteQuery -DataSource $env.Db -Query 'SELECT * FROM events')
        $events.Count | Should -Be 0
    }

    It 'processes multiple keyset pages without importing excluded templates' {
        $csv=@()
        1..251 | ForEach-Object {
            $csv += [pscustomobject]@{
                CAName='LAB-ISSUING-CA01';RequestID=[string]($_+1000);CertificateTemplate='WebServer';
                Subject="CN=web$_.example.test";Issuer='CN=LAB-ISSUING-CA01';SerialNumber="$_";
                CertificateHash="HASH$_";NotBefore='2026-01-01';NotAfter='2027-01-01';Requester='EXAMPLE\\svc-web'
            }
        }
        $csv | Export-Csv -LiteralPath $env.Csv -NoTypeInformation
        $first=@(Sync-CLMCertificates -ConfigPath $env.Config)
        $first[0].Read | Should -Be 251
        @(Get-CLMCertificate -ConfigPath $env.Config).Count | Should -Be 251
        [int]@(Get-CLMCollectionState -ConfigPath $env.Config)[0].last_request_id | Should -Be 1251
    }
}
