# Controlled enterprise CA acceptance (read-only first)

> **Do not configure the offline root CA as an issuing CA.** The intended source is the one online enterprise issuing CA and its one selected internal certificate template.

## 1. Prerequisite checks

- Use a 64-bit Windows management host with PowerShell 5.1, approved PSSQLite and PSPKI modules, and any required RSAT components.
- Obtain explicit CA database read permission and confirm normal CA management tools can enumerate the issuing CA without granting Issue/Manage Certificates.
- Back up an existing CLM SQLite database before any version upgrade; use a new test database for first production-CA scans.
- Copy `settings.example.json` to `settings.local.json`. Enter only the issuing CA, a single internal template **CN**, and a *test* `DatabasePath`. Set `MockMode=false`.
- Run `Get-CertificationAuthority -ComputerName '<your issuing CA DNS>' | Select-Object Name,ComputerName` (read-only) to validate the configured display/CA name; do not contact the offline root.

## 2. Preflight; no SQLite inventory writes

```powershell
Import-Module .\src\CLM.psm1 -Force
Sync-CLMCertificates -ConfigPath .\config\settings.local.json -DryRun -Full -Verbose
```

Validate **all** of these before going further:

- Exactly one scope appears: `CA_NAME/TEMPLATE_CN`.
- The read count is plausible for this template; auto-enrolled laptop templates are absent.
- `Get-IssuedRequest` returns a stable integer `RequestID`, `CertificateTemplate` matches the internal CN, `NotAfter` is valid, and subject/requester data map correctly.
- Multiple pages work without duplicate or out-of-order request IDs; the collector stops, rather than guessing, if an assumption fails.
- No certificate request, CA setting, CRL, certificate store, or offline-root server is changed.

If a test fails, capture a **sanitized** example of the PSPKI row's property names and types (not patient/server secrets) so the adapter can be adjusted. Avoid posting real internal CA hostnames or issued certificate metadata in public issue trackers.

## 3. Initial test database synchronization

```powershell
Sync-CLMCertificates -ConfigPath .\config\settings.local.json -Full
Get-CLMCollectionRun -ConfigPath .\config\settings.local.json
Get-CLMCollectionState -ConfigPath .\config\settings.local.json
Test-CLMDatabase -ConfigPath .\config\settings.local.json
Get-CLMCertificate -ConfigPath .\config\settings.local.json | Select-Object -First 10
```

Expected: one successful scope, a populated `last_request_id`, `Healthy=True`, a consistent read count, and no duplicate source keys. Independently compare a small sample of CA records to the CA console.

## 4. Idempotency and failure handling

1. Rerun without `-Full`: it should be incremental and normally return zero new rows until additional requests are issued.
2. Rerun with `-Full`: unchanged records should not add duplicate `discovered` events.
3. Assign an owner and status to a harmless record in the *test database*, full-rescan, verify both remain unchanged.
4. Perform failure injection **only on mock/test databases** using the included Pester suite; do **not** create triggers or deliberately break production reporting stores.
5. Verify a network/permission failure is logged as a failed `collection_runs` entry with no cursor advancement and no uncommitted data.

## 5. Boundaries of acceptance

Passing these checks establishes **AD CS selected-template collection and persistence only**. It does not establish complete certificate coverage, renewal safety, actual SMTP alert sending, revocation status, imported/public certificate discovery, or endpoint-deployment verification.
