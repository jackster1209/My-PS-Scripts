# Changelog

## 0.2.1 — SQLite compatibility hotfix

- Fixed `near "ON": syntax error` during certificate reconciliation by replacing SQLite 3.24+ `INSERT ... ON CONFLICT ... DO UPDATE` statements with plain `INSERT`/`UPDATE` under the existing per-scope transaction.
- Applied the same compatibility fix to the collection cursor and manual certificate owner/renewal status commands.
- Made manual ownership and renewal changes transactional (their associated audit events commit together).
- Preserved certificate primary keys, `first_seen`, owner assignments and renewal state during metadata refreshes; unchanged records refresh `last_seen`.
- Added tests for metadata updates and repeated manual changes (now 9 test cases). The injected-failure test now verifies the intended trigger error, preventing a false positive from an unrelated SQL syntax failure.
- No schema version bump: SQLite schema remains version 2. No database reset required for this hotfix.
- Confirmed SQL behavior using a local SQLite engine; Windows PowerShell + PSSQLite execution still needs validation in the target environment.

## 0.2.0 — Hardened AD CS collector and SQLite reconciliation

- Added fail-closed template CN and CA target validation.
- Added CA `RequestID` keyset pagination with bounded page sizes and record caps.
- Added full-scope validation before database writes, strict duplicate and malformed-row rejection.
- Added schema v2 with metadata record hash and per-scope persistent issuance cursor.
- Added atomic certificate/upsert/event/cursor commits, scope-level collection history, and sync mutex.
- Added `Sync-CLMCertificates -DryRun/-Full`, diagnostic commands, Pester mock/failure tests, and enterprise acceptance checklist.
- Retained admin settings/diagnostics, ownership, renewal bookkeeping, HTML/CSV reporting.

## 0.1.x — Initial developer prototype and admin console

- Basic mock/live AD CS inventory with SQLite persistence.
- Template discovery and selection, editable alert-level settings, manual revocation endpoint diagnostics.
