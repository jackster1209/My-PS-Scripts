# Run on a management station that has PSPKI + CA database read access.
param([Parameter(Mandatory)][string]$ComputerName)
Import-Module PSPKI -ErrorAction Stop
$ca=Get-CertificationAuthority -ComputerName $ComputerName
foreach($item in $ca) {
  Write-Host "CA: $($item.Name)" -ForegroundColor Cyan
  # Reads configuration metadata, not all issued certificate rows.
  $item | Get-CATemplate | Select-Object Name,DisplayName | Format-Table -AutoSize
}
