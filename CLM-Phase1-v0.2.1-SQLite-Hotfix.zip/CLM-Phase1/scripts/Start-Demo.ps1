param([string]$ConfigPath=(Join-Path $PSScriptRoot '../config/settings.example.json'))
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot '../src/CLM.psm1') -Force
Initialize-CLMDatabase -ConfigPath $ConfigPath
Sync-CLMCertificates -ConfigPath $ConfigPath
New-CLMReport -ConfigPath $ConfigPath
Get-CLMAlertPreview -ConfigPath $ConfigPath | Format-Table -AutoSize
