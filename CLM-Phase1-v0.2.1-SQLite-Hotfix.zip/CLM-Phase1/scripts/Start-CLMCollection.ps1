#Requires -Version 5.1
[CmdletBinding()]
param(
  [string]$ConfigPath=(Join-Path $PSScriptRoot '../config/settings.example.json'),
  [switch]$DryRun,
  [switch]$Full
)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot '../src/CLM.psm1') -Force
Sync-CLMCertificates -ConfigPath $ConfigPath -DryRun:$DryRun -Full:$Full | Format-Table -AutoSize
