#Requires -Version 5.1
<#
.SYNOPSIS
  Interactive, read-only-on-PKI CLM configuration and diagnostics console.
.DESCRIPTION
  Modifies only a local settings JSON file, never CA configuration.
  Defaults to mock template discovery; live discovery explicitly requires -Live.
.EXAMPLE
  .\scripts\Start-CLMAdmin.ps1
.EXAMPLE
  .\scripts\Start-CLMAdmin.ps1 -ConfigPath .\config\settings.local.json -Live
#>
[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot '..\config\settings.local.json'),
    [switch]$Live
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-PropertyValue {
    param($Object,[string]$Name,$Default=$null)
    if ($null -eq $Object) { return $Default }
    $property=$Object.PSObject.Properties[$Name]
    if ($null -ne $property) { return $property.Value }
    return $Default
}
function Set-PropertyValue {
    param($Object,[string]$Name,$Value)
    if ($null -eq $Object.PSObject.Properties[$Name]) { $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value }
    else { $Object.$Name=$Value }
}
function Read-Settings {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        $example=Join-Path $PSScriptRoot '..\config\settings.example.json'
        if (-not (Test-Path -LiteralPath $example)) { throw "Missing example settings: $example" }
        $dir=Split-Path -Parent $Path
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Copy-Item -LiteralPath $example -Destination $Path
        Write-Host "Created settings file from example: $Path" -ForegroundColor Yellow
    }
    $obj=Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
    if ($null -eq $obj.Templates) {throw 'Missing Templates config.'}
    if ($null -eq $obj.Alerts) {throw 'Missing Alerts config.'}
    return $obj
}
function Save-Settings {
    param($Settings,[string]$Path)
    # Preserve unrelated properties, verify serialized data, keep dated safety copy.
    $included=@(Get-PropertyValue $Settings.Templates 'Include' @())
    if ($included.Count -eq 0) { throw 'Cannot save an empty template allowlist (fail closed).' }
    $levels=@(Get-PropertyValue $Settings.Alerts 'Levels' @())
    if ($levels.Count -gt 0) {
      $seen=@{}
      foreach ($level in $levels) {
        $days=[int]$level.Days
        if ($days -lt 1 -or $days -gt 3650 -or $seen.ContainsKey($days)) { throw "Invalid/duplicate alert threshold: $days" }
        $seen[$days]=$true
        foreach ($email in @($level.Recipients)) {
          if ([string]::IsNullOrWhiteSpace([string]$email) -or -not ([string]$email -match '^[^\s@]+@[^\s@]+\.[^\s@]+$')) { throw "Invalid alert email address: $email" }
        }
      }
    }
    $json=$Settings | ConvertTo-Json -Depth 24
    $null=$json | ConvertFrom-Json -ErrorAction Stop
    $full=[System.IO.Path]::GetFullPath($Path)
    $dir=Split-Path -Parent $full
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $temp=Join-Path $dir ('.settings-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [System.IO.File]::WriteAllText($temp,$json,(New-Object System.Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $full) {
            $backup="$full.$(Get-Date -Format 'yyyyMMdd-HHmmss-fff').bak"
            # Replace is atomic on the same NTFS volume and creates a backup.
            [System.IO.File]::Replace($temp,$full,$backup)
        } else {
            [System.IO.File]::Move($temp,$full)
        }
    } finally { if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force} }
    Write-Host "Saved: $full (prior version backed up)" -ForegroundColor Green
}
function Ask-Choice {
    param([string]$Prompt,[string[]]$Options)
    for($i=0;$i -lt $Options.Count;$i++){Write-Host ('  [{0}] {1}' -f ($i+1),$Options[$i])}
    while($true){
        $inputValue=Read-Host $Prompt
        $number=0
        if([int]::TryParse($inputValue,[ref]$number) -and $number -ge 1 -and $number -le $Options.Count){return ($number - 1)}
        Write-Warning 'Enter a number from the menu.'
    }
}
function Get-TemplateCandidates {
    param($Settings,[bool]$LiveMode)
    if (-not $LiveMode) {
        $path=Join-Path $PSScriptRoot '..\fixtures\sample-templates.csv'
        return @(Import-Csv -LiteralPath $path | ForEach-Object {
            [pscustomobject]@{Name=$_.Name;DisplayName=$_.DisplayName;Oid=$_.Oid;CA='MOCK'}
        })
    }
    if (-not (Get-Module -ListAvailable PSPKI)) {throw 'PSPKI not installed. Install/review it before live CA discovery.'}
    Import-Module PSPKI -ErrorAction Stop
    $results=New-Object System.Collections.ArrayList
    foreach($spec in @($Settings.IssuingCAs)){
        if([string]::IsNullOrWhiteSpace([string]$spec.ComputerName) -or [string]::IsNullOrWhiteSpace([string]$spec.Name)) {throw 'Each issuing CA needs ComputerName and Name.'}
        $ca=@(Get-CertificationAuthority -ComputerName $spec.ComputerName -ErrorAction Stop | Where-Object { $_.Name -eq $spec.Name })
        if($ca.Count -ne 1) {throw "Expected exactly one CA named '$($spec.Name)' on '$($spec.ComputerName)'; found $($ca.Count)."}
        # PSPKI Get-CATemplate is read-only here. Never call Set-CATemplate.
        $templates=@($ca[0] | Get-CATemplate -ErrorAction Stop)
        foreach($t in $templates){
            $name=[string](Get-PropertyValue $t 'Name' '')
            if([string]::IsNullOrWhiteSpace($name)){continue}
            $display=[string](Get-PropertyValue $t 'DisplayName' $name)
            $oid=[string](Get-PropertyValue $t 'Oid' '')
            [void]$results.Add([pscustomobject]@{Name=$name;DisplayName=$display;Oid=$oid;CA=$spec.Name})
        }
    }
    return @($results | Sort-Object Name,CA -Unique)
}
function Edit-Templates {
    param($Settings,[string]$Path,[bool]$LiveMode)
    $candidates=@(Get-TemplateCandidates $Settings $LiveMode | Sort-Object Name)
    if($candidates.Count -eq 0){Write-Warning 'No templates returned. Configuration unchanged.';return}
    $included=@(Get-PropertyValue $Settings.Templates 'Include' @())
    $excluded=@(Get-PropertyValue $Settings.Templates 'Exclude' @())
    Write-Host "`nDiscovered $($candidates.Count) published templates. [x] = included, [!] = denylisted." -ForegroundColor Cyan
    for($i=0;$i -lt $candidates.Count;$i++){
        $t=$candidates[$i]
        $marker=if($excluded -contains $t.Name){'!'}elseif($included -contains $t.Name){'x'}else{' '}
        Write-Host ('{0,3}. [{1}] {2}  ({3}) [{4}]' -f ($i+1),$marker,$t.DisplayName,$t.Name,$t.CA)
    }
    Write-Host 'Enter comma-separated template numbers to TOGGLE selection, or A to select all non-denylisted, N to clear pending selection, Q to cancel.'
    $reply=(Read-Host 'Selection').Trim()
    if($reply -match '^(?i:q)$'){return}
    $selection=[System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($name in $included){[void]$selection.Add([string]$name)}
    if($reply -match '^(?i:n)$'){$selection.Clear()}
    elseif($reply -match '^(?i:a)$'){
        foreach($t in $candidates){if($excluded -notcontains $t.Name){[void]$selection.Add($t.Name)}}
    }else{
        foreach($part in @($reply -split ',')){
            $value=0
            if(-not [int]::TryParse($part.Trim(),[ref]$value) -or $value -lt 1 -or $value -gt $candidates.Count){throw "Invalid template index: $part"}
            $name=$candidates[$value-1].Name
            if($excluded -contains $name){Write-Warning "Template '$name' is denylisted; not selecting.";continue}
            if(-not $selection.Remove($name)){[void]$selection.Add($name)}
        }
    }
    foreach($name in @($selection)){if($excluded -contains $name){[void]$selection.Remove($name)}}
    if($selection.Count -eq 0){Write-Warning 'Refusing empty allowlist. No changes saved.';return}
    $names=@($selection | Sort-Object)
    Write-Host "`nProposed allowlist: $($names -join ', ')" -ForegroundColor Cyan
    if((Read-Host 'Save template selection? (yes/no)') -ne 'yes'){return}
    Set-PropertyValue $Settings.Templates 'Include' $names
    Save-Settings $Settings $Path
}
function Edit-Alerts {
    param($Settings,[string]$Path)
    $levels=@(Get-PropertyValue $Settings.Alerts 'Levels' @())
    if($levels.Count -eq 0){
        foreach($days in @($Settings.Alerts.ThresholdDays | Sort-Object -Descending)){
            $levels+= [pscustomobject]@{Days=[int]$days;Enabled=$true;Recipients=@(Get-PropertyValue $Settings.Alerts 'Recipients' @());IncludeOwner=$true;EscalateUnassigned=$false;Mode='Digest'}
        }
    }
    while($true){
        Write-Host "`nAlert levels (configuration only; no email transmission implemented):" -ForegroundColor Cyan
        for($i=0;$i -lt $levels.Count;$i++){
            $l=$levels[$i]
            Write-Host ('{0}. {1}d | enabled={2} | mode={3} | owner={4} | escalate unassigned={5} | recipients={6}' -f ($i+1),$l.Days,$l.Enabled,$l.Mode,$l.IncludeOwner,$l.EscalateUnassigned,(@($l.Recipients) -join ';'))
        }
        Write-Host '[S] Save  [A] Add threshold  [R] Remove threshold  [Q] Cancel'
        $entry=(Read-Host 'Level number or action').Trim()
        if($entry -match '^(?i:q)$'){return}
        if($entry -match '^(?i:s)$'){
            if($levels.Count -eq 0){Write-Warning 'At least one alert level required.';continue}
            Set-PropertyValue $Settings.Alerts 'Levels' @($levels | Sort-Object Days -Descending)
            # Old alert preview reads ThresholdDays; keep it in sync with active levels.
            Set-PropertyValue $Settings.Alerts 'ThresholdDays' @($levels | Where-Object Enabled | ForEach-Object {[int]$_.Days} | Sort-Object -Descending)
            Save-Settings $Settings $Path
            return
        }
        if($entry -match '^(?i:a)$'){
            $raw=Read-Host 'New threshold (days, 1-3650)';$days=0
            if(-not [int]::TryParse($raw,[ref]$days) -or $days -lt 1 -or $days -gt 3650 -or @($levels | Where-Object Days -eq $days).Count){Write-Warning 'Invalid or duplicate threshold.';continue}
            $levels+= [pscustomobject]@{Days=$days;Enabled=$true;Recipients=@();IncludeOwner=$true;EscalateUnassigned=$false;Mode='Digest'}
            continue
        }
        if($entry -match '^(?i:r)$'){
            $raw=Read-Host 'Threshold days to remove';$days=0
            if([int]::TryParse($raw,[ref]$days)){$levels=@($levels | Where-Object Days -ne $days)}
            continue
        }
        $index=0
        if(-not [int]::TryParse($entry,[ref]$index) -or $index -lt 1 -or $index -gt $levels.Count){Write-Warning 'Unknown action.';continue}
        $item=$levels[$index-1]
        $item.Enabled= ((Read-Host "Enable $($item.Days)d alert? (yes/no) [currently $($item.Enabled)]") -eq 'yes')
        $item.IncludeOwner= ((Read-Host 'Include assigned certificate owner? (yes/no)') -eq 'yes')
        $item.EscalateUnassigned= ((Read-Host 'Escalate certificates without owners? (yes/no)') -eq 'yes')
        $mode=Read-Host 'Delivery behavior: Digest or Individual'
        if($mode -notin @('Digest','Individual')){Write-Warning 'Invalid behavior; keeping previous.'}else{$item.Mode=$mode}
        $emails=Read-Host 'Additional recipients (comma-separated emails; blank=none)'
        $item.Recipients=@($emails -split ',' | ForEach-Object { $_.Trim() } | Where-Object {$_})
        Write-Host 'Updated in memory. Choose S to persist.'
    }
}
function Invoke-UrlCheck {
    param([string]$Url,[int]$TimeoutMs=10000)
    $result=[ordered]@{Url=$Url;Reachable=$false;HttpStatus=$null;Message='';Evidence='Connectivity only — not revocation validity'}
    $uri=$null
    if(-not [uri]::TryCreate($Url,[System.UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https')){
        $result.Message='Only HTTP(S) URLs supported for this connectivity test.';return [pscustomobject]$result
    }
    $request=$null;$response=$null;$stream=$null
    try {
        $request=[System.Net.HttpWebRequest]::Create($uri)
        $request.Method='GET';$request.Timeout=$TimeoutMs;$request.ReadWriteTimeout=$TimeoutMs
        $request.AllowAutoRedirect=$false
        $response=[System.Net.HttpWebResponse]$request.GetResponse()
        $result.HttpStatus=[int]$response.StatusCode
        if($result.HttpStatus -eq 200){
            $stream=$response.GetResponseStream()
            if($stream.ReadByte() -ge 0){$result.Reachable=$true;$result.Message='HTTP 200 with non-empty response'}
            else{$result.Message='HTTP 200 but empty response'}
        }else{$result.Message="HTTP $($result.HttpStatus)"}
    }catch [System.Net.WebException] {
        if($_.Exception.Response){
            $result.HttpStatus=[int]$_.Exception.Response.StatusCode
            $_.Exception.Response.Dispose()
        }
        $result.Message=$_.Exception.Message
    }catch{$result.Message=$_.Exception.Message}
    finally{
        if($stream){$stream.Dispose()};if($response){$response.Dispose()}
        if($request){$request.Abort()}
    }
    [pscustomobject]$result
}
function Test-CertificateRevocation {
    param([string]$CertificatePath,[int]$TimeoutSeconds=60)
    $path=(Resolve-Path -LiteralPath $CertificatePath -ErrorAction Stop).Path
    $cert=New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($path)
    Write-Host "`nSubject: $($cert.Subject)" -ForegroundColor Cyan
    Write-Host "Issuer:  $($cert.Issuer)"
    Write-Host "Expiry:  $($cert.NotAfter)"
    Write-Host 'Advertised CDP/AIA/OCSP extensions (best-effort display; parsing depends on OS locale):'
    foreach($ext in $cert.Extensions){
        if($ext.Oid.Value -in @('2.5.29.31','1.3.6.1.5.5.7.1.1','2.5.29.46')) {
            Write-Host "  $($ext.Oid.Value): $($ext.Format($true))"
        }
    }
    if(-not (Get-Command certutil.exe -ErrorAction SilentlyContinue)) {throw 'certutil.exe is required for Windows chain/revocation validation.'}
    $stdout=Join-Path ([System.IO.Path]::GetTempPath()) ('clm-certutil-'+[guid]::NewGuid().ToString('N')+'.out')
    $stderr=$stdout+'.err'
    try {
        $proc=Start-Process -FilePath 'certutil.exe' -ArgumentList @('-verify','-urlfetch',('"'+$path+'"')) -PassThru -NoNewWindow -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        if(-not $proc.WaitForExit($TimeoutSeconds*1000)){
            try{$proc.Kill()}catch{}
            Write-Warning 'certutil timed out. Result is inconclusive.';return
        }
        $proc.Refresh()
        $out=(Get-Content -LiteralPath $stdout -Raw -ErrorAction SilentlyContinue)
        $err=(Get-Content -LiteralPath $stderr -Raw -ErrorAction SilentlyContinue)
        Write-Host "certutil exit code: $($proc.ExitCode)" -ForegroundColor $(if($proc.ExitCode -eq 0){'Green'}else{'Yellow'})
        Write-Host $out
        if($err){Write-Warning $err}
        Write-Host 'Interpret per-certificate CDP, OCSP, chain, and trust errors in the verbose output; a successful result does not guarantee every advertised URL works.' -ForegroundColor Yellow
    }finally{
        foreach($file in @($stdout,$stderr)){if(Test-Path -LiteralPath $file){Remove-Item -LiteralPath $file -Force}}
    }
}
function Show-Diagnostics {
    param($Settings,[string]$Path)
    $diag=Get-PropertyValue $Settings 'Diagnostics' $null
    if($null -eq $diag){
        $diag=[pscustomobject]@{CrlUrls=@();CertificateFiles=@()}
        Set-PropertyValue $Settings 'Diagnostics' $diag
    }
    while($true){
        Write-Host "`nPKI Diagnostics (read-only)" -ForegroundColor Cyan
        Write-Host '[1] Check configured HTTP CRL URLs (reachability only)'
        Write-Host '[2] Validate a local issued certificate via Windows chain/CRL/OCSP (certutil -verify -urlfetch)'
        Write-Host '[3] Edit CRL URL test list'
        Write-Host '[4] Display local CA issuer settings'
        Write-Host '[0] Back'
        $choice=Read-Host 'Select'
        switch($choice){
          '1'{
            $urls=@(Get-PropertyValue $diag 'CrlUrls' @())
            if($urls.Count -eq 0){Write-Warning 'No CRL URLs configured.'}
            else{$urls | ForEach-Object {Invoke-UrlCheck -Url $_} | Format-Table -AutoSize -Wrap}
          }
          '2'{
            $file=Read-Host 'Local issued certificate .cer/.crt (not private key) path'
            if(-not [string]::IsNullOrWhiteSpace($file)) {Test-CertificateRevocation -CertificatePath $file}
          }
          '3'{
            Write-Host ('Current: '+(@($diag.CrlUrls) -join ', '))
            $new=Read-Host 'Enter comma-separated HTTP(S) CRL URLs, or blank to clear'
            $urls=@($new -split ',' | ForEach-Object {$_.Trim()} | Where-Object {$_})
            foreach($url in $urls){
                $uri=$null
                if(-not [uri]::TryCreate($url,[System.UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https')) {throw "Invalid HTTP(S) URL: $url"}
            }
            Set-PropertyValue $diag 'CrlUrls' $urls
            if((Read-Host 'Save CRL URL list? (yes/no)') -eq 'yes'){Save-Settings $Settings $Path}
          }
          '4'{$Settings.IssuingCAs | Format-Table -AutoSize}
          '0'{return}
          default{Write-Warning 'Unknown action.'}
        }
    }
}

$settings=Read-Settings $ConfigPath
while($true){
    Write-Host "`n=== CLM Admin ===" -ForegroundColor Cyan
    Write-Host "Settings: $([System.IO.Path]::GetFullPath($ConfigPath))"
    Write-Host "Template discovery mode: $(if($Live){'LIVE READ-ONLY'}else{'MOCK'})"
    Write-Host '[1] Discover and select issuing CA templates'
    Write-Host '[2] Edit alert thresholds, behavior, and recipients'
    Write-Host '[3] CRL / OCSP diagnostic tools'
    Write-Host '[4] Show current configuration summary'
    Write-Host '[5] Reload settings from disk'
    Write-Host '[0] Exit'
    $choice=Read-Host 'Select'
    try {
        switch($choice){
          '1'{Edit-Templates $settings $ConfigPath ([bool]$Live)}
          '2'{Edit-Alerts $settings $ConfigPath}
          '3'{Show-Diagnostics $settings $ConfigPath}
          '4'{
              [pscustomobject]@{MockMode=$settings.MockMode;IssuingCAs=(@($settings.IssuingCAs.Name) -join ', ');IncludedTemplates=(@($settings.Templates.Include) -join ', ');ExcludedTemplates=(@($settings.Templates.Exclude) -join ', ');Thresholds=(@($settings.Alerts.ThresholdDays) -join ', ')} | Format-List
            }
          '5'{$settings=Read-Settings $ConfigPath;Write-Host 'Reloaded.'}
          '0'{return}
          default{Write-Warning 'Unknown action.'}
        }
    }catch{Write-Warning "Operation failed, config not necessarily changed: $($_.Exception.Message)"; $settings=Read-Settings $ConfigPath}
}
