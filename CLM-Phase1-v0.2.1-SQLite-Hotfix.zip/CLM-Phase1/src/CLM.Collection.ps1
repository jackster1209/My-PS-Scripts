# Collection and reconciliation engine v0.2. Windows PowerShell 5.1 compatible.
# The root CA is never contacted. All live operations are read-only CA database queries.

function Assert-CLMCollectionConfig {
    param($Config)
    $allowed = @($Config.Templates.Include | ForEach-Object { [string]$_ } | Where-Object { $_.Trim() })
    if ($allowed.Count -eq 0) { throw 'Templates.Include cannot be empty (fail closed).' }
    foreach ($template in $allowed) {
        if ($template -cnotmatch '^[A-Za-z0-9_.-]+$') {
            throw "Unsafe or unsupported internal template name '$template'. Use the template CN, not its display name."
        }
    }
    $effective = @($allowed | Where-Object { @($Config.Templates.Exclude) -notcontains $_ } | Select-Object -Unique)
    if ($effective.Count -eq 0) { throw 'All included templates are excluded. Refusing unrestricted collection.' }
    $cas = @($Config.IssuingCAs)
    if ($cas.Count -eq 0) { throw 'No issuing CAs configured.' }
    $names = @{}
    foreach ($ca in $cas) {
            if ([string]::IsNullOrWhiteSpace([string]$ca.Name) -or
                [string]::IsNullOrWhiteSpace([string]$ca.ComputerName)) { throw 'Issuing CA must have Name and ComputerName.' }
            if ($ca.PSObject.Properties['IsOfflineRoot'] -and $ca.IsOfflineRoot) {
                throw "Offline root '$($ca.Name)' must never be configured as an issuing CA."
            }
            if ($names.ContainsKey([string]$ca.Name)) { throw "Duplicate CA name '$($ca.Name)' in configuration." }
            $names[[string]$ca.Name] = $true
    }
}

function Get-CLMCollectionOptions {
    param($Config)
    $pageSize = 250
    $fullDays = 7
    $maxRecords = 50000
    if ($Config.PSObject.Properties['Collection'] -and $null -ne $Config.Collection) {
        if ($Config.Collection.PSObject.Properties['PageSize']) { $pageSize = [int]$Config.Collection.PageSize }
        if ($Config.Collection.PSObject.Properties['FullReconcileIntervalDays']) { $fullDays = [int]$Config.Collection.FullReconcileIntervalDays }
        if ($Config.Collection.PSObject.Properties['MaxRecordsPerScope']) { $maxRecords = [int]$Config.Collection.MaxRecordsPerScope }
    }
    if ($pageSize -lt 1 -or $pageSize -gt 5000) { throw 'Collection.PageSize must be 1..5000.' }
    if ($fullDays -lt 1 -or $fullDays -gt 365) { throw 'Collection.FullReconcileIntervalDays must be 1..365.' }
    if ($maxRecords -lt $pageSize -or $maxRecords -gt 1000000) { throw 'Collection.MaxRecordsPerScope is outside the permitted range.' }
    [pscustomobject]@{ PageSize=$pageSize; FullDays=$fullDays; MaxRecords=$maxRecords }
}

function Open-CLMConnection {
    param([Parameter(Mandatory)][string]$DatabasePath)
    Assert-CLMDependencies
    $connection = New-SQLiteConnection -DataSource $DatabasePath
    if ($connection.State -ne [System.Data.ConnectionState]::Open) { $connection.Open() }
    try {
        $cmd = $connection.CreateCommand()
        try {
            $cmd.CommandText = 'PRAGMA busy_timeout=10000; PRAGMA foreign_keys=ON;'
            [void]$cmd.ExecuteNonQuery()
        } finally { $cmd.Dispose() }
        return $connection
    } catch { $connection.Dispose(); throw }
}

function Invoke-CLMCommand {
    param(
        [Parameter(Mandatory)]$Connection,
        [Parameter(Mandatory)][string]$Sql,
        [hashtable]$Arguments=@{},
        $Transaction=$null,
        [ValidateSet('NonQuery','Scalar','Rows')][string]$Return='NonQuery'
    )
    $cmd=$Connection.CreateCommand()
    try {
        $cmd.CommandText=$Sql
        if ($null -ne $Transaction) { $cmd.Transaction=$Transaction }
        foreach ($name in $Arguments.Keys) {
            $value=$Arguments[$name]
            if ($null -eq $value) { $value=[DBNull]::Value }
            [void]$cmd.Parameters.AddWithValue("@$name",$value)
        }
        if ($Return -eq 'Scalar') { return $cmd.ExecuteScalar() }
        if ($Return -eq 'Rows') {
            $result=@()
            $reader=$cmd.ExecuteReader()
            try {
                while ($reader.Read()) {
                    $o=[ordered]@{}
                    for($i=0;$i -lt $reader.FieldCount;$i++) {
                        $v=$reader.GetValue($i)
                        if ($v -is [DBNull]) { $v=$null }
                        $o[$reader.GetName($i)]=$v
                    }
                    $result += [pscustomobject]$o
                }
            } finally { $reader.Dispose() }
            return $result
        }
        return $cmd.ExecuteNonQuery()
    } finally { $cmd.Dispose() }
}

function Initialize-CLMDatabase {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConfigPath)
    $cfg=Read-CLMConfig $ConfigPath
    Assert-CLMCollectionConfig $cfg
    $dir=Split-Path -Parent $cfg.DatabasePath
    if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    $db=Open-CLMConnection $cfg.DatabasePath
    try {
        # Base schema is retained for compatibility with the earlier admin, report and ownership commands.
        $base=@'
CREATE TABLE IF NOT EXISTS certificates (
 id INTEGER PRIMARY KEY AUTOINCREMENT, source_key TEXT NOT NULL UNIQUE,
 sha256 TEXT, sha1 TEXT, issuing_ca TEXT, request_id TEXT,
 subject TEXT NOT NULL, issuer TEXT, serial_number TEXT, template TEXT, requester TEXT,
 not_before TEXT, not_after TEXT NOT NULL, source TEXT NOT NULL,
 first_seen TEXT NOT NULL, last_seen TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_cert_expiry ON certificates(not_after);
CREATE INDEX IF NOT EXISTS ix_cert_template ON certificates(template);
CREATE TABLE IF NOT EXISTS owners (
 id INTEGER PRIMARY KEY AUTOINCREMENT, owner_name TEXT NOT NULL UNIQUE COLLATE NOCASE,
 email TEXT, team TEXT
);
CREATE TABLE IF NOT EXISTS assignments (
 certificate_id INTEGER PRIMARY KEY REFERENCES certificates(id),
 owner_id INTEGER NOT NULL REFERENCES owners(id), assigned_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS renewal_workflows (
 certificate_id INTEGER PRIMARY KEY REFERENCES certificates(id), status TEXT NOT NULL DEFAULT 'unassigned',
 replacement_id INTEGER REFERENCES certificates(id), notes TEXT, updated_at TEXT NOT NULL,
 CHECK(status IN ('unassigned','identified','assigned','in_progress','deployment_pending','verified_complete','blocked','retired'))
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, certificate_id INTEGER REFERENCES certificates(id),
 event_type TEXT NOT NULL, description TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS collection_runs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, started_at TEXT NOT NULL,
 finished_at TEXT, status TEXT NOT NULL, imported_count INTEGER NOT NULL DEFAULT 0, error TEXT
);
CREATE TABLE IF NOT EXISTS notifications (
 certificate_id INTEGER NOT NULL REFERENCES certificates(id), threshold_days INTEGER NOT NULL,
 destination TEXT NOT NULL, notified_at TEXT NOT NULL,
 PRIMARY KEY(certificate_id,threshold_days,destination)
);
'@
        # Configuration schema updates are transactional except for journal mode (set outside transaction).
        [void](Invoke-CLMCommand $db 'PRAGMA journal_mode=WAL;')
        $tx=$db.BeginTransaction()
        try {
            [void](Invoke-CLMCommand $db $base @{} $tx)
            $version=[int](Invoke-CLMCommand $db 'PRAGMA user_version;' @{} $tx 'Scalar')
            if ($version -gt 2) { throw "SQLite schema version $version is newer than supported v2. Refusing to write." }
            $cols=@(Invoke-CLMCommand $db 'PRAGMA table_info(certificates);' @{} $tx 'Rows' | ForEach-Object { $_.name })
            if ($cols -notcontains 'record_hash') {
                [void](Invoke-CLMCommand $db 'ALTER TABLE certificates ADD COLUMN record_hash TEXT;' @{} $tx)
            }
            $cursorDdl=@'
CREATE TABLE IF NOT EXISTS collection_cursors (
 scope_key TEXT PRIMARY KEY, last_request_id INTEGER NOT NULL DEFAULT 0,
 last_full_scan TEXT, last_success_at TEXT NOT NULL
);
'@
            [void](Invoke-CLMCommand $db $cursorDdl @{} $tx)
            if ($version -lt 2) { [void](Invoke-CLMCommand $db 'PRAGMA user_version=2;' @{} $tx) }
            $tx.Commit()
        } catch { $tx.Rollback(); throw } finally { $tx.Dispose() }
    } finally { $db.Dispose() }
    [pscustomobject]@{Database=$cfg.DatabasePath;Initialized=$true;SchemaVersion=2}
}

function ConvertTo-CLMUtc {
    param([Parameter(Mandatory)]$Value)
    if ($Value -is [datetime]) {
        $d=[datetime]$Value
        if ($d.Kind -eq [DateTimeKind]::Unspecified) { $d=[datetime]::SpecifyKind($d,[DateTimeKind]::Local) }
        return $d.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ',[Globalization.CultureInfo]::InvariantCulture)
    }
    $dt=[datetimeoffset]::Parse([string]$Value,[Globalization.CultureInfo]::InvariantCulture,
        [Globalization.DateTimeStyles]::AssumeLocal)
    return $dt.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ssZ',[Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-CLMRecord {
    param([Parameter(Mandatory)]$Item,[Parameter(Mandatory)][string]$CAName)
    $template=Get-CLMProperty $Item @('CertificateTemplate','Template')
    $rid=Get-CLMProperty $Item @('RequestID','RequestId')
    $subject=Get-CLMProperty $Item @('Subject','DistinguishedName','CommonName')
    $until=Get-CLMProperty $Item @('NotAfter','Expires')
    if ([string]::IsNullOrWhiteSpace($rid) -or $rid -notmatch '^[0-9]+$' -or [long]$rid -le 0 -or [long]$rid -gt [int]::MaxValue) {
        throw "CA '$CAName' returned a record without a valid positive RequestID."
    }
    if ([string]::IsNullOrWhiteSpace($subject) -or [string]::IsNullOrWhiteSpace($until)) {
        throw "CA '$CAName', RequestID '$rid' is missing Subject/CommonName or NotAfter."
    }
    if ([string]::IsNullOrWhiteSpace($template)) { throw "CA '$CAName', RequestID '$rid' has no certificate template." }
    $from=Get-CLMProperty $Item @('NotBefore')
    $start=$null
    if ($from) { $start=ConvertTo-CLMUtc $from }
    $end=ConvertTo-CLMUtc $until
    if ($start -and [string]::CompareOrdinal($start,$end) -ge 0) { throw "Invalid validity dates on CA '$CAName' request '$rid'." }
    $key="ADCS:$CAName`:$([long]$rid)"
    [pscustomobject]@{
        SourceKey=$key; CA=$CAName; RequestId=[int]$rid; Subject=$subject
        Template=$template; Issuer=(Get-CLMProperty $Item @('Issuer','IssuerName'))
        Serial=(Get-CLMProperty $Item @('SerialNumber','Serial'))
        Sha1=(Get-CLMProperty $Item @('CertificateHash','Thumbprint','SHA1'))
        Sha256=(Get-CLMProperty $Item @('SHA256','FingerprintSHA256'))
        Requester=(Get-CLMProperty $Item @('Requester','Request.RequesterName'))
        NotBefore=$start; NotAfter=$end; Source='ADCS'
    }
}

function Get-CLMRecordHash {
    param($Record)
    $parts=@($Record.SourceKey,$Record.CA,$Record.RequestId,$Record.Subject,$Record.Template,
             $Record.Issuer,$Record.Serial,$Record.Sha1,$Record.Sha256,$Record.Requester,
             $Record.NotBefore,$Record.NotAfter)
    $data=[Text.Encoding]::UTF8.GetBytes(($parts | ForEach-Object { [string]$_ }) -join "`n")
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($data))).Replace('-','') } finally { $sha.Dispose() }
}

function Get-CLMCollectionState {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConfigPath)
    $cfg=Read-CLMConfig $ConfigPath
    if (-not (Test-Path -LiteralPath $cfg.DatabasePath)) { return }
    Invoke-CLMSql $cfg.DatabasePath 'SELECT scope_key,last_request_id,last_full_scan,last_success_at FROM collection_cursors ORDER BY scope_key' @{}
}

function Get-CLMScopeRecords {
    param($Config,[string]$CAName,[string]$Template,[int]$Cursor,[int]$PageSize,[int]$Limit,$LiveCA)
    $all=New-Object System.Collections.Generic.List[object]
    $seen=New-Object 'System.Collections.Generic.HashSet[int]'
    $last=$Cursor
    do {
        if ($Config.MockMode) {
            # The same keyset window and normalization are used as in live collection.
            $batch=@(Import-Csv -LiteralPath $Config.MockCsvPath |
                Where-Object { $_.CAName -eq $CAName -and $_.CertificateTemplate -eq $Template -and [long]$_.RequestID -gt $last } |
                Sort-Object {[long]$_.RequestID} | Select-Object -First $PageSize)
        } else {
            # PSPKI supports RequestID -gt and CertificateTemplate -eq server-side; always Page 1.
            $batch=@(Get-IssuedRequest -CertificationAuthority $LiveCA `
                -Filter @("CertificateTemplate -eq $Template", "RequestID -gt $last") `
                -Property @('CertificateTemplate','CertificateHash','Request.RequesterName', 'DistinguishedName','SerialNumber','NotBefore','NotAfter') `
                -Page 1 -PageSize $PageSize -ErrorAction Stop)
        }
        if ($batch.Count -eq 0) { break }
        # Ensure the cursor is strictly monotonic; never skip, repeat, or silently truncate a page.
        $normalized=New-Object System.Collections.Generic.List[object]
        foreach($item in $batch) {
            $record=ConvertTo-CLMRecord -Item $item -CAName $CAName
            if ($record.Template -ine $Template) { throw "Unexpected template '$($record.Template)' in the '$Template' scope." }
            if ($record.RequestId -le $last) { throw "Non-monotonic RequestID $($record.RequestId) after $last on $CAName/$Template." }
            if (-not $seen.Add([int]$record.RequestId)) { throw "Duplicate RequestID $($record.RequestId) in $CAName/$Template collection." }
            $normalized.Add($record)
        }
        $sorted=@($normalized | Sort-Object RequestId)
        $newLast=[int]$sorted[-1].RequestId
        if ($newLast -le $last) { throw "Cursor stalled in $CAName/$Template." }
        foreach($record in $sorted) { $all.Add($record) }
        if ($all.Count -gt $Limit) { throw "Safety limit $Limit records reached for $CAName/$Template. Increase Collection.MaxRecordsPerScope deliberately." }
        $last=$newLast
    } while ($batch.Count -eq $PageSize)
    return [pscustomobject]@{Records=$all.ToArray();HighWatermark=$last;Count=$all.Count}
}

function Get-CLMScopeSummary {
    param($Connection,[object[]]$Records,[string]$Scope,[string]$Mode,[int]$StartCursor,[int]$HighWatermark)
    $new=0;$updated=0;$unchanged=0
    foreach($record in $Records) {
        $prior=@()
        if ($null -ne $Connection) {
            $prior=@(Invoke-CLMCommand $Connection 'SELECT record_hash FROM certificates WHERE source_key=@key' @{key=$record.SourceKey} $null 'Rows')
        }
        $hash=Get-CLMRecordHash $record
        if ($prior.Count -eq 0) { $new++ }
        elseif ($prior[0].record_hash -ne $hash) { $updated++ }
        else { $unchanged++ }
    }
    [pscustomobject]@{ Scope=$Scope;Mode=$Mode;Read=$Records.Count;New=$new;Updated=$updated;
        Unchanged=$unchanged;StartCursor=$StartCursor;HighWatermark=$HighWatermark }
}

function Save-CLMScope {
    param($Connection,$Summary,[object[]]$Records,[string]$Now)
    $tx=$Connection.BeginTransaction()
    try {
        foreach($record in $Records) {
            $hash=Get-CLMRecordHash $record
            $existing=@(Invoke-CLMCommand $Connection 'SELECT id,record_hash FROM certificates WHERE source_key=@key' @{key=$record.SourceKey} $tx 'Rows')
            $arguments=@{ key=$record.SourceKey; ca=$record.CA; rid=[string]$record.RequestId;
                subject=$record.Subject; template=$record.Template; issuer=$record.Issuer;
                serial=$record.Serial; sha1=$record.Sha1; sha256=$record.Sha256;
                requester=$record.Requester; start=$record.NotBefore; expiry=$record.NotAfter;
                now=$Now; hash=$hash }
            # Avoid SQLite 3.24+ UPSERT syntax: older PSSQLite bundles reject ON CONFLICT ... DO UPDATE.
            # The existence check and mutation run under the same SQLite transaction.
            if ($existing.Count -eq 0) {
                $insertSql=@'
INSERT INTO certificates
(source_key,sha256,sha1,issuing_ca,request_id,subject,issuer,serial_number,template,requester,not_before,not_after,source,first_seen,last_seen,record_hash)
VALUES(@key,@sha256,@sha1,@ca,@rid,@subject,@issuer,@serial,@template,@requester,@start,@expiry,'ADCS',@now,@now,@hash);
'@
                [void](Invoke-CLMCommand $Connection $insertSql $arguments $tx)
            } elseif ($existing[0].record_hash -ne $hash) {
                # Never replace the row: its id is referenced by owners and renewal workflows.
                # first_seen is historical metadata and must remain unchanged.
                $updateSql=@'
UPDATE certificates SET
sha256=@sha256,sha1=@sha1,issuing_ca=@ca,request_id=@rid,
subject=@subject,issuer=@issuer,serial_number=@serial,template=@template,
requester=@requester,not_before=@start,not_after=@expiry,
last_seen=@now,record_hash=@hash
WHERE source_key=@key;
'@
                [void](Invoke-CLMCommand $Connection $updateSql $arguments $tx)
            } else {
                # Even an unchanged CA record was observed again in this full scan.
                [void](Invoke-CLMCommand $Connection 'UPDATE certificates SET last_seen=@now WHERE source_key=@key' `
                    @{now=$Now;key=$record.SourceKey} $tx)
            }
            $kind=$null
            if ($existing.Count -eq 0) { $kind='discovered' }
            elseif ($existing[0].record_hash -ne $hash) { $kind='source_changed' }
            if ($kind) {
                $eventSql=@'
INSERT INTO events(certificate_id,event_type,description,created_at)
SELECT id,@kind,@description,@now FROM certificates WHERE source_key=@key;
'@
                [void](Invoke-CLMCommand $Connection $eventSql @{kind=$kind;description="CA inventory $($record.CA) / $($record.RequestId)";now=$Now;key=$record.SourceKey} $tx)
            }
        }
        # Cursors advance in the *same* commit as the certificate records. An interrupted run cannot lose rows.
        $lastFull=$null
        if ($Summary.Mode -eq 'full') { $lastFull=$Now }
        $existingCursor=@(Invoke-CLMCommand $Connection `
            'SELECT last_request_id,last_full_scan FROM collection_cursors WHERE scope_key=@scope' `
            @{scope=$Summary.Scope} $tx 'Rows')
        if ($existingCursor.Count -eq 0) {
            $cursorSql=@'
INSERT INTO collection_cursors(scope_key,last_request_id,last_full_scan,last_success_at)
VALUES(@scope,@last,@full,@now);
'@
        } else {
            $cursorSql=@'
UPDATE collection_cursors SET
last_request_id=MAX(last_request_id,@last),
last_full_scan=COALESCE(@full,last_full_scan),
last_success_at=@now
WHERE scope_key=@scope;
'@
        }
        [void](Invoke-CLMCommand $Connection $cursorSql @{scope=$Summary.Scope;last=$Summary.HighWatermark;full=$lastFull;now=$Now} $tx)
        $tx.Commit()
    } catch { $tx.Rollback(); throw } finally { $tx.Dispose() }
}

function New-CLMCollectionRun {
    param($Connection,[string]$Source,[string]$Now)
    [void](Invoke-CLMCommand $Connection "INSERT INTO collection_runs(source,started_at,status) VALUES(@source,@now,'running')" @{source=$Source;now=$Now})
    return [long](Invoke-CLMCommand $Connection 'SELECT last_insert_rowid()' @{} $null 'Scalar')
}
function Complete-CLMCollectionRun {
    param($Connection,[long]$RunId,[string]$Status,[int]$Processed,[string]$ErrorText='')
    $runUpdateSql=@'
UPDATE collection_runs SET finished_at=@now,status=@status,imported_count=@count,error=@error
WHERE id=@id AND status='running';
'@
    [void](Invoke-CLMCommand $Connection $runUpdateSql @{now=[datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ');status=$Status;count=$Processed;error=$ErrorText;id=$RunId})
}

function Get-CLMCollectionRun {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConfigPath,[ValidateRange(1,1000)][int]$Last=20)
    $cfg=Read-CLMConfig $ConfigPath
    if (-not (Test-Path -LiteralPath $cfg.DatabasePath)) { return }
    Invoke-CLMSql $cfg.DatabasePath 'SELECT * FROM collection_runs ORDER BY id DESC LIMIT @limit' @{limit=$Last}
}

function Test-CLMDatabase {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConfigPath)
    $cfg=Read-CLMConfig $ConfigPath
    if (-not (Test-Path -LiteralPath $cfg.DatabasePath)) { throw 'SQLite database does not exist.' }
    $db=Open-CLMConnection $cfg.DatabasePath
    try {
        $integrity=[string](Invoke-CLMCommand $db 'PRAGMA quick_check;' @{} $null 'Scalar')
        $foreignKeys=@(Invoke-CLMCommand $db 'PRAGMA foreign_key_check;' @{} $null 'Rows')
        $version=[int](Invoke-CLMCommand $db 'PRAGMA user_version;' @{} $null 'Scalar')
        [pscustomobject]@{Database=$cfg.DatabasePath;SchemaVersion=$version;
            QuickCheck=$integrity;ForeignKeyViolations=$foreignKeys.Count;
            Healthy=($integrity -eq 'ok' -and $foreignKeys.Count -eq 0 -and $version -eq 2)}
    } finally { $db.Dispose() }
}

function Sync-CLMCertificates {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConfigPath,[switch]$DryRun,[switch]$Full)
    $cfg=Read-CLMConfig $ConfigPath
    Assert-CLMCollectionConfig $cfg
    $options=Get-CLMCollectionOptions $cfg
    $dbExists=Test-Path -LiteralPath $cfg.DatabasePath
    $db=$null
    $mutex=$null
    $lockAcquired=$false
    try {
        if (-not $DryRun) {
            $sha=[Security.Cryptography.SHA256]::Create()
            try { $id=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($cfg.DatabasePath)))).Replace('-','').Substring(0,24) }
            finally { $sha.Dispose() }
            $mutex=New-Object -TypeName System.Threading.Mutex -ArgumentList @($false,"Local\CLM-Sync-$id")
            $lockAcquired=$mutex.WaitOne(0)
            if (-not $lockAcquired) { throw 'Another CLM sync is already running against this database.' }
            Initialize-CLMDatabase -ConfigPath $ConfigPath | Out-Null
        }
        if ($dbExists -or -not $DryRun) { $db=Open-CLMConnection $cfg.DatabasePath }
        $liveCAs=@{}
        if (-not $cfg.MockMode) {
            if (-not (Get-Module -ListAvailable -Name PSPKI)) { throw 'Live AD CS collection requires PSPKI.' }
            Import-Module PSPKI -ErrorAction Stop
        }
        $specs=if ($cfg.MockMode) {
            # Enumerate only CA names explicitly declared in config, even in mock mode.
            @($cfg.IssuingCAs)
        } else { @($cfg.IssuingCAs) }
        foreach($spec in $specs) {
            if ($null -eq $spec -or -not $spec.Name) { throw 'Every issuing CA must have a Name.' }
            foreach($template in @($cfg.Templates.Include | Select-Object -Unique)) {
                if (-not (Test-CLMTemplate $template $cfg)) { continue }
                $scope="$($spec.Name)/$template"
                $cursor=0;$lastFull=$null
                if ($db) {
                    $state=@(Invoke-CLMCommand $db 'SELECT last_request_id,last_full_scan FROM collection_cursors WHERE scope_key=@scope' @{scope=$scope} $null 'Rows')
                    if ($state.Count) { $cursor=[int]$state[0].last_request_id; $lastFull=$state[0].last_full_scan }
                }
                $mode='incremental'
                if ($Full -or -not $lastFull -or ([datetime]::UtcNow - [datetime]::Parse([string]$lastFull).ToUniversalTime()).TotalDays -ge $options.FullDays) {
                    $mode='full'
                }
                $scanCursor=if ($mode -eq 'full') { 0 } else { $cursor }
                $runId=0
                if (-not $DryRun) { $runId=New-CLMCollectionRun $db "ADCS:$scope" ([datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')) }
                try {
                    $live=$null
                    if (-not $cfg.MockMode) {
                        if (-not $liveCAs.ContainsKey([string]$spec.Name)) {
                            $caMatches=@(Get-CertificationAuthority -ComputerName $spec.ComputerName -ErrorAction Stop |
                                Where-Object { $_.Name -eq $spec.Name })
                            if ($caMatches.Count -ne 1) {
                                throw "Expected exactly one CA '$($spec.Name)' on '$($spec.ComputerName)'; found $($caMatches.Count)."
                            }
                            $liveCAs[[string]$spec.Name]=$caMatches[0]
                        }
                        $live=$liveCAs[[string]$spec.Name]
                    }
                    $result=Get-CLMScopeRecords -Config $cfg -CAName $spec.Name -Template $template `
                        -Cursor $scanCursor -PageSize $options.PageSize -Limit $options.MaxRecords -LiveCA $live
                    $summary=Get-CLMScopeSummary $db $result.Records $scope $mode $scanCursor ([math]::Max($cursor,$result.HighWatermark))
                    $summary | Add-Member NoteProperty DryRun ([bool]$DryRun)
                    if (-not $DryRun) {
                        Save-CLMScope $db $summary $result.Records ([datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))
                        Complete-CLMCollectionRun $db $runId 'success' $result.Count
                    }
                    Write-Output $summary
                } catch {
                    if (-not $DryRun -and $runId -gt 0) {
                        Complete-CLMCollectionRun $db $runId 'failed' 0 $_.Exception.Message
                    }
                    throw "Collection failed for CA/template '$scope': $($_.Exception.Message)"
                }
            }
        }
    } finally {
        if ($db) { $db.Dispose() }
        if ($mutex) {
            if ($lockAcquired) { [void]$mutex.ReleaseMutex() }
            $mutex.Dispose()
        }
    }
}
