Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-CLMConfig {
    [CmdletBinding()] param([Parameter(Mandatory)][string]$Path)
    $resolved=(Resolve-Path -LiteralPath $Path).Path
    $cfg=Get-Content -LiteralPath $resolved -Raw | ConvertFrom-Json
    $base=Split-Path -Parent $resolved
    foreach($name in @('DatabasePath','MockCsvPath')) {
        if ($cfg.PSObject.Properties.Name -contains $name -and $cfg.$name) {
            if (-not [System.IO.Path]::IsPathRooted([string]$cfg.$name)) { $cfg.$name=[System.IO.Path]::GetFullPath((Join-Path $base $cfg.$name)) }
        }
    }
    if(-not [System.IO.Path]::IsPathRooted([string]$cfg.Reporting.OutputDirectory)) {
        $cfg.Reporting.OutputDirectory=[System.IO.Path]::GetFullPath((Join-Path $base $cfg.Reporting.OutputDirectory))
    }
    if(@($cfg.Templates.Include).Count -eq 0){ throw 'Template Include must not be empty: fail-closed protection against unbounded CA queries.' }
    return $cfg
}
function Assert-CLMDependencies {
    if (-not (Get-Module -ListAvailable -Name PSSQLite)) { throw 'Missing PSSQLite. Install-Module PSSQLite -Scope CurrentUser' }
    Import-Module PSSQLite -ErrorAction Stop
}
function Invoke-CLMSql {
    param([string]$DatabasePath,[string]$Query,[hashtable]$Parameters=@{})
    Assert-CLMDependencies
    Invoke-SqliteQuery -DataSource $DatabasePath -Query $Query -SqlParameters $Parameters
}
function Test-CLMTemplate {
    param([string]$Template,$Config)
    if([string]::IsNullOrWhiteSpace($Template)) {return $false}
    $allow=@($Config.Templates.Include | ForEach-Object { [string]$_ })
    $deny=@($Config.Templates.Exclude | ForEach-Object { [string]$_ })
    return (($allow -contains $Template) -and ($deny -notcontains $Template))
}
function Get-CLMProperty {
    param($Object,[string[]]$Names)
    foreach($n in $Names) {
        $prop=$Object.PSObject.Properties[$n]
        if($null -ne $prop -and $null -ne $prop.Value -and [string]$prop.Value -ne '') {
            return [string]$prop.Value
        }
        # PSPKI AD CS database rows also expose a Properties indexer.
        $container=$Object.PSObject.Properties['Properties']
        if($null -ne $container -and $null -ne $container.Value) {
            try {
                $v=$container.Value[$n]
                if($null -ne $v -and [string]$v -ne '') { return [string]$v }
            } catch { }
        }
    }
    return ''
}
. (Join-Path $PSScriptRoot 'CLM.Collection.ps1')

function Get-CLMCertificate {
    [CmdletBinding()]param([Parameter(Mandatory)][string]$ConfigPath,[switch]$Unassigned,[int]$ExpiringWithinDays=0)
    $cfg=Read-CLMConfig $ConfigPath
    $where='WHERE 1=1';$params=@{}
    if($Unassigned){$where+=' AND a.certificate_id IS NULL'}
    if($PSBoundParameters.ContainsKey('ExpiringWithinDays')) {
      $where+=' AND c.not_after <= @deadline AND c.not_after >= @today'
      $params.deadline=[datetime]::UtcNow.AddDays($ExpiringWithinDays).ToString('yyyy-MM-ddTHH:mm:ssZ')
      $params.today=[datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    }
    $q="SELECT c.id,c.source_key,c.subject,c.template,c.issuing_ca,c.not_after,c.requester,c.sha1,o.owner_name,o.email,r.status AS renewal_status FROM certificates c LEFT JOIN assignments a ON a.certificate_id=c.id LEFT JOIN owners o ON o.id=a.owner_id LEFT JOIN renewal_workflows r ON r.certificate_id=c.id $where ORDER BY c.not_after,c.id"
    Invoke-CLMSql $cfg.DatabasePath $q $params
}
function Set-CLMCertificateOwner {
    [CmdletBinding()]param([Parameter(Mandatory)][string]$ConfigPath,[Parameter(Mandatory)][int]$CertificateId,
      [Parameter(Mandatory)][string]$OwnerName,[Parameter(Mandatory)][string]$Email,[string]$Team='')
    $cfg=Read-CLMConfig $ConfigPath
    $present=Invoke-CLMSql $cfg.DatabasePath 'SELECT id FROM certificates WHERE id=@id' @{id=$CertificateId}
    if(-not $present){throw "Certificate id $CertificateId not found"}
    $now=[datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    # These writes must be atomic: a failed assignment must not leave an orphan owner/event.
    # Standard INSERT + UPDATE works with older bundled SQLite engines (pre-3.24).
    $db=Open-CLMConnection $cfg.DatabasePath
    try {
        $tx=$db.BeginTransaction()
        try {
            $owner=@(Invoke-CLMCommand $db 'SELECT id FROM owners WHERE owner_name=@name COLLATE NOCASE' @{name=$OwnerName} $tx 'Rows')
            if ($owner.Count -eq 0) {
                [void](Invoke-CLMCommand $db 'INSERT INTO owners(owner_name,email,team) VALUES(@name,@email,@team)' `
                    @{name=$OwnerName;email=$Email;team=$Team} $tx)
            } else {
                [void](Invoke-CLMCommand $db 'UPDATE owners SET email=@email,team=@team WHERE id=@id' `
                    @{id=$owner[0].id;email=$Email;team=$Team} $tx)
            }
            $assigned=@(Invoke-CLMCommand $db 'SELECT certificate_id FROM assignments WHERE certificate_id=@id' `
                @{id=$CertificateId} $tx 'Rows')
            if ($assigned.Count -eq 0) {
                $insertAssignment='INSERT INTO assignments(certificate_id,owner_id,assigned_at) SELECT @cert,id,@now FROM owners WHERE owner_name=@name COLLATE NOCASE;'
                [void](Invoke-CLMCommand $db $insertAssignment @{cert=$CertificateId;now=$now;name=$OwnerName} $tx)
            } else {
                $updateAssignment='UPDATE assignments SET owner_id=(SELECT id FROM owners WHERE owner_name=@name COLLATE NOCASE),assigned_at=@now WHERE certificate_id=@cert;'
                [void](Invoke-CLMCommand $db $updateAssignment @{cert=$CertificateId;now=$now;name=$OwnerName} $tx)
            }
            [void](Invoke-CLMCommand $db 'INSERT INTO events(certificate_id,event_type,description,created_at) VALUES(@id,@type,@description,@now)' `
                @{id=$CertificateId;type='owner_assigned';description=$OwnerName;now=$now} $tx)
            $tx.Commit()
        } catch { $tx.Rollback(); throw } finally { $tx.Dispose() }
    } finally { $db.Dispose() }
    Get-CLMCertificate -ConfigPath $ConfigPath | Where-Object id -eq $CertificateId
}
function Set-CLMRenewalStatus {
    [CmdletBinding()]param([Parameter(Mandatory)][string]$ConfigPath,[Parameter(Mandatory)][int]$CertificateId,
    [Parameter(Mandatory)][ValidateSet('unassigned','identified','assigned','in_progress','deployment_pending','verified_complete','blocked','retired')][string]$Status,
    [string]$Notes='')
    if($Status -eq 'verified_complete'){throw 'Automatic or manual verified_complete requires deployment evidence; not implemented in Phase 1.'}
    $cfg=Read-CLMConfig $ConfigPath
    $present=Invoke-CLMSql $cfg.DatabasePath 'SELECT id FROM certificates WHERE id=@id' @{id=$CertificateId}
    if(-not $present){throw "Certificate id $CertificateId not found"}
    $now=[datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    $db=Open-CLMConnection $cfg.DatabasePath
    try {
        $tx=$db.BeginTransaction()
        try {
            $existing=@(Invoke-CLMCommand $db 'SELECT certificate_id FROM renewal_workflows WHERE certificate_id=@id' `
                @{id=$CertificateId} $tx 'Rows')
            if ($existing.Count -eq 0) {
                [void](Invoke-CLMCommand $db 'INSERT INTO renewal_workflows(certificate_id,status,notes,updated_at) VALUES(@id,@status,@notes,@now)' `
                    @{id=$CertificateId;status=$Status;notes=$Notes;now=$now} $tx)
            } else {
                [void](Invoke-CLMCommand $db 'UPDATE renewal_workflows SET status=@status,notes=@notes,updated_at=@now WHERE certificate_id=@id' `
                    @{id=$CertificateId;status=$Status;notes=$Notes;now=$now} $tx)
            }
            [void](Invoke-CLMCommand $db 'INSERT INTO events(certificate_id,event_type,description,created_at) VALUES(@id,@type,@description,@now)' `
                @{id=$CertificateId;type='renewal_status';description="$Status - $Notes";now=$now} $tx)
            $tx.Commit()
        } catch { $tx.Rollback(); throw } finally { $tx.Dispose() }
    } finally { $db.Dispose() }
}
function Get-CLMAlertPreview {
    [CmdletBinding()]param([Parameter(Mandatory)][string]$ConfigPath)
    $cfg=Read-CLMConfig $ConfigPath
    $rows=@(Get-CLMCertificate -ConfigPath $ConfigPath)
    $today=[datetime]::UtcNow
    # Levels are authoritative when available; fallback remains compatible with v1 settings.
    $levels=@()
    if($cfg.Alerts.PSObject.Properties['Levels'] -and @($cfg.Alerts.Levels).Count -gt 0) {
      $levels=@($cfg.Alerts.Levels | Where-Object { $_.Enabled -eq $true } | Sort-Object {[int]$_.Days} -Descending)
    } else {
      $levels=@($cfg.Alerts.ThresholdDays | ForEach-Object {
        [pscustomobject]@{Days=[int]$_;Mode='Digest';Recipients=@($cfg.Alerts.Recipients);IncludeOwner=$true;EscalateUnassigned=$false}
      } | Sort-Object Days -Descending)
    }
    foreach($row in $rows){
      $remaining=([datetime]::Parse([string]$row.not_after).ToUniversalTime()-$today).TotalDays
      if($remaining -le 0 -or $row.renewal_status -eq 'verified_complete' -or $row.renewal_status -eq 'retired'){continue}
      foreach($level in $levels){
        $threshold=[int]$level.Days
        if($remaining -le [double]$threshold){
          $recipients=@($level.Recipients | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
          if($level.IncludeOwner -and -not [string]::IsNullOrWhiteSpace([string]$row.email)){$recipients+= [string]$row.email}
          $isUnassigned=[string]::IsNullOrWhiteSpace([string]$row.owner_name)
          [pscustomobject]@{CertificateId=$row.id;Subject=$row.subject;Owner=$row.owner_name;Email=$row.email;
            DaysRemaining=[math]::Ceiling($remaining);ThresholdDays=$threshold;Template=$row.template;Status=$row.renewal_status;
            DeliveryMode=$level.Mode;Recipients=(@($recipients | Sort-Object -Unique) -join ';');
            NeedsOwnerEscalation=($isUnassigned -and [bool]$level.EscalateUnassigned)}
          break
        }
      }
    }
}
function New-CLMReport {
    [CmdletBinding()]param([Parameter(Mandatory)][string]$ConfigPath)
    $cfg=Read-CLMConfig $ConfigPath
    New-Item -ItemType Directory -Path $cfg.Reporting.OutputDirectory -Force | Out-Null
    $rows=@(Get-CLMCertificate -ConfigPath $ConfigPath)
    $csv=Join-Path $cfg.Reporting.OutputDirectory 'certificates.csv'
    $html=Join-Path $cfg.Reporting.OutputDirectory 'certificates.html'
    $rows | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
    $style='body{font-family:Segoe UI,Arial,sans-serif;margin:2rem;color:#222}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:.5rem;text-align:left}th{background:#e8eff8}tr:nth-child(even){background:#f7f8fa}'
    $table=if($rows.Count){$rows | ConvertTo-Html -Fragment}else{'<p>No certificates in the selected scope.</p>'}
    $body="<h1>CLM Phase 1 Inventory</h1><p>Read-only report generated $([datetime]::UtcNow.ToString('u')) UTC</p>$table"
    ConvertTo-Html -Head "<meta charset='utf-8'><style>$style</style>" -Body $body -Title 'CLM Inventory' | Set-Content -LiteralPath $html -Encoding UTF8
    [pscustomobject]@{Html=$html;Csv=$csv;Count=$rows.Count}
}
Export-ModuleMember -Function Read-CLMConfig,Initialize-CLMDatabase,Sync-CLMCertificates,Get-CLMCollectionState,Get-CLMCollectionRun,Test-CLMDatabase,Get-CLMCertificate,Set-CLMCertificateOwner,Set-CLMRenewalStatus,Get-CLMAlertPreview,New-CLMReport
