# Certificate Lifecycle Manager (CLM) — Phase 1A, v0.2.1

**Status: developer preview. SQL compatibility hotfix v0.2.1. Pester execution has been reported by a Windows tester, but the revised code has not yet been re-run under Windows PowerShell/PSSQLite.**

This release replaces the original per-row database writes with a **hardened, template-scoped AD CS collector and transactional SQLite reconciliation**. It retains the prior interactive Admin Console, certificate ownership/status commands, and HTML/CSV reports.

## Guardrails and scope

- Query **explicitly configured online issuing CA(s)** only. **Never contact the offline root CA.** An optional `IsOfflineRoot: true` setting is explicitly rejected.
- `Templates.Include` must contain at least one safe internal template **CN** and must leave an effective allowlist after exclusions. **No unrestricted CA scanning** is available.
- All live CA interaction is **read-only**. No revocation, issue/deny, renewal, export of private keys, or endpoint modifications.
- `-DryRun` collects, validates and compares results without writing inventory, cursor, or run records. If a database exists, it is opened to compare with its current state; SQLite may maintain sidecar journal files.
- Collection of public/imported certificates and TLS deployments is **not yet included**. This milestone addresses AD CS inventory and existing manual lifecycle bookkeeping.
- CA database rows can contain sensitive inventory data. Protect the database, reports and copies with filesystem ACLs.

## Prerequisites

- **Windows PowerShell 5.1, 64-bit** on a management workstation or management server.
- `PSSQLite` PowerShell module (database layer), installed from an organization-approved source.
- `PSPKI` PowerShell module for live CA queries (and any required RSAT dependencies); read-only **CA database Read** permission to the targeted enterprise issuing CA.
- `Pester 5 or 6` to run the tests (optional for normal use). The Windows inbox Pester 3.4 module can remain installed side by side; no uninstall is needed.

```powershell
Install-Module PSSQLite -Scope CurrentUser
Install-Module Pester -MinimumVersion 5.0 -Scope CurrentUser -Force
# On the AD CS management host when testing live:
Install-Module PSPKI -Scope CurrentUser
```

Review approved versions and transfer signed packages through the appropriate change process if the management host is disconnected from the internet.

## Quick start without an AD CS environment

Extract this ZIP to a writable test folder. From that folder:

```powershell
Import-Module .\src\CLM.psm1 -Force

# Safe preview: no database created on a new install
Sync-CLMCertificates -ConfigPath .\config\settings.example.json -DryRun

# Initial mock full scan, creates data/clm.sqlite
Sync-CLMCertificates -ConfigPath .\config\settings.example.json

# Subsequent scans are incremental until the next full interval
Sync-CLMCertificates -ConfigPath .\config\settings.example.json

# Force a full recheck of all issued rows from the selected template
Sync-CLMCertificates -ConfigPath .\config\settings.example.json -Full

# Review state and database integrity
Get-CLMCollectionState -ConfigPath .\config\settings.example.json
Get-CLMCollectionRun -ConfigPath .\config\settings.example.json
Test-CLMDatabase -ConfigPath .\config\settings.example.json

# Retained functionality
Get-CLMCertificate -ConfigPath .\config\settings.example.json
New-CLMReport -ConfigPath .\config\settings.example.json
Get-CLMAlertPreview -ConfigPath .\config\settings.example.json
```

Alternatively, use `scripts/Start-CLMCollection.ps1 -DryRun`, `-Full`, or no switch. `scripts/Start-Demo.ps1` still runs collection and reporting. The example settings now include **one** illustrative `WebServer` template and mock collection is enabled; adjust the template for your CA before live use.

## Configuration

Create `config/settings.local.json` by copying `settings.example.json`. Do not put internal CA names, CRL URLs or recipients in a public repository.

```json
{
  "MockMode": false,
  "IssuingCAs": [ { "Name": "YOUR-ISSUING-CA-NAME", "ComputerName": "issuing-ca.example.internal" } ],
  "Templates": { "Include": [ "YOUR-TEMPLATE-CN" ], "Exclude": [] },
  "Collection": {
    "PageSize": 250,
    "FullReconcileIntervalDays": 7,
    "MaxRecordsPerScope": 50000
  }
}
```

**This is an excerpt**, not a complete replacement for the JSON file. Keep `DatabasePath`, `MockCsvPath`, `Alerts`, `Reporting`, and `Diagnostics` from the example. The `Name` must match PSPKI's issuing CA name and the template must be its **internal name**, not display name. `IsOfflineRoot` must not be set to true on any configured CA.

`PageSize` must be 1–5000; `MaxRecordsPerScope` limits unexpectedly large scans. For an environment where one template contains the certificates of interest, include **only that one template**. The separate admin tool (`scripts/Start-CLMAdmin.ps1`) can still edit allowed templates and alert-level recipients; no real email sending is implemented yet.

## How the new collector works

1. Validate the effective template allowlist and configured issuing CA targets before connecting.
2. Read the per-CA/template `last_request_id` cursor and `last_full_scan` timestamp from `collection_cursors`. First runs are full; later runs are incremental until the configured periodic full scan or `-Full`.
3. Query PSPKI using **server-side** filters for `CertificateTemplate -eq TEMPLATE` and `RequestID -gt CURSOR`, always with `-Page 1 -PageSize N`. Validate the returned records and move the cursor forward to the highest RequestID each page. Reject nonmonotonic/duplicate IDs, malformed records, unexpected templates, and exceeded size limits.
4. Read the **complete** scope before applying any changes. A collection failure does not insert partial rows or advance the cursor.
5. In a single SQLite transaction, insert or update records with SQLite-compatible DML, add a `discovered` or `source_changed` event only when applicable, and update the scope cursor/full-scan timestamp. A failed commit rolls back all three.
6. Preserve all existing certificate IDs, ownership assignments, renewal states and notes. Never infer renewal completion or deletion from a missing scan result.
7. Append one `collection_runs` result per attempted CA/template scope; status `failed` records errors, while `success` records the number of rows read in `imported_count` (legacy column name).

**Why not offset pagination?** PSPKI's documented RequestID keyset pattern queries `RequestID -gt` with `-Page 1` repeatedly and advances the cursor, avoiding increasingly expensive offsets on large CA databases. However, the assumption of ordered, monotonic RequestIDs and returned field mappings must still be validated against your specific PSPKI version and issuing CA. See [PKI Solutions' CA database query guidance](https://www.pkisolutions.com/adcs-certification-authority-database-query-numbers/).

**Revocation caveat:** `Get-IssuedRequest` enumerates currently issued records, not a complete historic revocation ledger. A previously stored certificate absent on a later full query is *not* marked revoked, removed or retired. A separate revoked-request/status collector will be required for accurate lifecycle status.

## SQLite and migration

- Version 2 adds `certificates.record_hash` and `collection_cursors`, while retaining prior tables (`owners`, `assignments`, `renewal_workflows`, `events`, `notifications`, `collection_runs`). It sets `PRAGMA user_version=2`. Migration is invoked on normal sync and is **not** invoked by `-DryRun`.
- Writes use a shared connection and a transaction **per issuing CA/template**. If multiple scopes are configured, an earlier successful scope can be committed before a later scope fails; the later scope remains unchanged.
- The local database uses SQLite WAL mode and a single-process Windows mutex during sync. Restrict writes to a **local disk**, not a shared SMB folder.
- **Before upgrading an existing v0.1 database, back it up using an approved SQLite backup method while no process is writing.** Do not blindly copy the `.sqlite` file while WAL writers are active; copy the whole quiesced database or use SQLite's backup API.
- An old v0.1 row has no `record_hash`; it will appear as changed on its first full scan after migration. Certificate IDs and owner/workflow records remain stable.

## Tests and enterprise acceptance

Run on Windows with Pester 5 or 6:

```powershell
Invoke-Pester .\tests\Collection.Tests.ps1 -Output Detailed
```

The test suite checks dry-run behavior, allowlist enforcement, multi-page keyset reads, cursor persistence, repeat scans, preservation of owner and renewal state, malformed-row rejection, and forced SQLite transaction rollback.

To prepare for the **first live CA test**, follow `docs/Enterprise-Acceptance.md`. Start with `-DryRun -Full`, validate the targeted template and field mapping, compare a few rows against the CA console, then enable SQLite writes only on a **separate test database**.


## v0.2.1 compatibility hotfix and retest

A Windows tester reported three failures containing `SQL logic error or missing database near "ON": syntax error` in v0.2.0. The project used SQLite's `INSERT ... ON CONFLICT ... DO UPDATE` form in the certificate and cursor reconcilers; this syntax requires SQLite 3.24.0+. The PSSQLite DLL actually loaded may differ between installs. v0.2.1 uses ordinary `INSERT`/`UPDATE` statements instead, inside existing transactions. Manual owner and renewal commands are updated too. Schema version remains 2.

**For a clean mock retest:** replace the extracted project with the v0.2.1 ZIP (or back up and replace `src/CLM.Collection.ps1`, `src/CLM.psm1` and `tests/Collection.Tests.ps1`). `Invoke-Pester .\tests\Collection.Tests.ps1 -Output Detailed` is expected to run 9 tests; actual execution on Windows is still required. You do **not** need to uninstall Pester 3.4 if 6.x is installed side by side.

To identify the SQLite runtime: `Import-Module PSSQLite; Invoke-SqliteQuery -DataSource "$env:TEMP\clm-version-check.sqlite" -Query 'SELECT sqlite_version() AS Version;'`. This creates only an isolated temporary test database.

**Don't delete an existing populated SQLite file merely to apply the hotfix.** Stop writers, back it up safely, and run `Test-CLMDatabase` after the updated module is imported. The example mock configuration points at `data/clm.sqlite`; use an isolated copy of the project for testing.

## Known exclusions / future work

- Public certificate, imported certificate store, TLS endpoint, SAN and deployment discovery (planned collectors).
- Complete AD CS revocation tracking and deliberate template identity/OID normalization.
- Automatic renewal or confirmed deployment-verification flows.
- SMTP delivery and deduplicated notification ledger (alert preview and Admin Console configuration only).
- Complete signed-root and CRL/OCSP diagnostics beyond the existing manual Admin Console tools.
- Native PowerShell execution and live PKI behavior: **not yet tested by the authoring environment**. SQL DDL and transaction semantics have been exercised using Python's SQLite engine, but the PowerShell/PSSQLite interface requires Windows validation.
